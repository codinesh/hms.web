export enum PaymentMode {
    cash,
    card,
    upi
  }