 enum HealthConditions {
  BP = 0,
  Sugar = 1,
  Fertility = 2,
  Heart = 3,
  Others = 4,
}

export default HealthConditions
