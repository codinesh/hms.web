export default interface IUser {
  id: string
  name: string
  loggedIn: boolean
}
