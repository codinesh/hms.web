import Home from './dashboard'

export default Home
